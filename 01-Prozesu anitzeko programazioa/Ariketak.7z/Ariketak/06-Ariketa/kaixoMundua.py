
def to_uppercase(input_string):
    return input_string.upper()

if __name__ == "__main__":
    sarrera = "kaixo mundua"
    emaitza = to_uppercase(sarrera)
    print(emaitza)