/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package azterketamaiderarizmendiarrieta;
/**
 *
 * @author maider
 */
public class AzterketaMaiderArizmendiarrieta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Hariak sortu
        Pultsularia p1 = new Pultsularia("Bob");
        Pultsularia p2 = new Pultsularia("Alice");
        
        // Hariak jaurti
        p1.start();
        p2.start();
    }
}
