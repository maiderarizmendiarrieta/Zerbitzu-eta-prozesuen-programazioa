public class Parking {
    private int available;
    private Autoa[] autoak;

    public void func() {
        for (int i = 1; i <= 10; i++) {
            Autoa autoa = new Autoa(i);
            for (int j = 0; j < autoak.length; j++) {
                if (autoak[j] != null) {
                    autoa.sartu();
                    autoak[j] = autoa;
                    
                }
            }
            

            autoa.irten();
        }
    }
}
