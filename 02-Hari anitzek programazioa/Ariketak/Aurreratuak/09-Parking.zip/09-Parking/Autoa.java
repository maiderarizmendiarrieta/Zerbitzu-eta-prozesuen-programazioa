import java.util.Random;

public class Autoa extends Thread {
    private int id_;
    private boolean aparkatuta;

    private Random random = new Random();

    public Autoa(int id) {
        this.id_ = id;
        this.aparkatuta = false;
    }

    public int getId_() {
        return id_;
    }

    synchronized public void sartu() {
        try {
            while (!aparkatuta) {
                wait();
            }
            System.out.println("Autoa " + id_ + " sartu egin da.");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

    public void irten() {
        System.out.println("Autoa " + id_ + " irten egin da.");
        this.aparkatuta = false;
    }

    public void run() {
        try {
            sartu();
            Thread.sleep(random.nextInt(3000));
            irten();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}