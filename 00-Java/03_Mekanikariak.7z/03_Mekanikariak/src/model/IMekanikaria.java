package model;

public interface IMekanikaria {
    void autoaKonpondu() throws MekanikariaException;
    int kobratu();
    void biharEtorri();
}
